# Enlaces

- [Jenkins](http://157.253.238.75:8080/jenkins-misovirtual/)
- [Sonar](http://157.253.238.75:8080/sonar-misovirtual/)
- [GitInspector](https://misw-4104-web.github.io/202212_Equipo11/reports/)
